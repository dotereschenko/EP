## Black

All done! ✨ 🍰 ✨
1 file left unchanged.

## Flake8

./streamlit_app.py:9:80: E501 line too long (86 > 79 characters)
./streamlit_app.py:64:80: E501 line too long (85 > 79 characters)
./streamlit_app.py:93:80: E501 line too long (88 > 79 characters)

## Isort

-

## Pylint

************* Module hw1.streamlit_app
streamlit_app.py:1:0: C0114: Missing module docstring (missing-module-docstring)
streamlit_app.py:8:0: C0116: Missing function or method docstring (missing-function-docstring)
streamlit_app.py:9:4: W0622: Redefining built-in 'input' (redefined-builtin)
<unknown>:430: SyntaxWarning: invalid escape sequence '\.'
streamlit_app.py:13:0: C0116: Missing function or method docstring (missing-function-docstring)
streamlit_app.py:29:0: C0116: Missing function or method docstring (missing-function-docstring)
streamlit_app.py:59:0: C0116: Missing function or method docstring (missing-function-docstring)
streamlit_app.py:69:0: C0116: Missing function or method docstring (missing-function-docstring)
streamlit_app.py:76:0: C0116: Missing function or method docstring (missing-function-docstring)
streamlit_app.py:80:0: C0116: Missing function or method docstring (missing-function-docstring)
streamlit_app.py:82:4: R1705: Unnecessary "else" after "return", remove the "else" and de-indent the code inside it (no-else-return)
streamlit_app.py:83:19: E1101: Module 'openai' has no 'ChatCompletion' member (no-member)
streamlit_app.py:93:19: E1101: Module 'openai' has no 'Completion' member (no-member)
streamlit_app.py:97:0: C0116: Missing function or method docstring (missing-function-docstring)
streamlit_app.py:98:4: C0103: Variable name "API_URL" doesn't conform to snake_case naming style (invalid-name)
streamlit_app.py:102:19: W3101: Missing timeout argument for method 'requests.post' can cause your program to hang indefinitely (missing-timeout)

------------------------------------------------------------------
Your code has been rated at 6.35/10 (previous run: 6.35/10, +0.00)

